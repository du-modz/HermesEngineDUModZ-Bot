package = 'hbctool'
project = 'hbctool'
project_no_spaces = project.replace(' ', '')
version = '0.1.5'
description = ('A command-line interface for disassembling and assembling'
               'the Hermes Bytecode')
authors = ['bongtrop', 'ErbaZZ']
authors_string = ', '.join(authors)
emails = ['bongtrop@gmail.com', 'weerawat.paw@gmail.com']
license = 'MIT'
url = 'https://github.com/bongtrop/hbctool'